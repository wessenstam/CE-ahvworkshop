﻿# Set Variables:
# This version just has all the variables at the top.
# These variables are HOST specific...
$vmhost = "192.168.81.141"


# VLAN_4004
$vSwitch = "vSwitch0"
$esxhost = Get-VMHost $vmhost
$hostview = $esxhost | Get-View
$ns = Get-View -Id $hostview.ConfigManager.NetworkSystem

$pgspec = New-Object VMware.Vim.HostPortGroupSpec
$pgspec.vswitchName = "vSwitch0"
$pgspec.Name = "VLAN_4004"
$pgspec.vlanId = "4004"
$ns.UpdatePortGroup($pgspec.Name,$pgspec)

# VLAN_4004
$vSwitch = "vSwitch0"
$esxhost = Get-VMHost $vmhost
$hostview = $esxhost | Get-View
$ns = Get-View -Id $hostview.ConfigManager.NetworkSystem

$pgspec = New-Object VMware.Vim.HostPortGroupSpec
$pgspec.vswitchName = "vSwitch0"
$pgspec.Name = "VLAN_1002"
$pgspec.vlanId = "1002"
$ns.UpdatePortGroup($pgspec.Name,$pgspec)
