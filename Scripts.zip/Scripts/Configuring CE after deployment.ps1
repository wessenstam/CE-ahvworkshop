﻿
# **********************************************************************************
# * Nutanix CE stuff to be done                                                    *
# **********************************************************************************
# This script is deleting the default storagepool and container in the CE version
# Then sets the names according to the IP-address and table in the workshop document

# Load the Nutanix modules
Add-PsSnapin NutanixCmdletsPSSnapin

# Set parameters
$NTNXUser="admin"
$NTNXPassword="nutanix/4u"

# Use the below parameter on Commandlets version 4.6 and higher..
$NTNXPwdSec=ConvertTo-SecureString -String $NTNXPassword -AsPlainText -Force

$CVMS="192.168.81.110"
#$CVMS="192.168.3.60","192.168.3.61","192.168.3.62","192.168.3.63","192.168.3.64","192.168.3.65","192.168.3.66","192.168.3.67"#,"192.168.3.68","192.168.3.69"
$CEid=1


foreach ($CVM in $CVMS){

    # Conncet to the first CVS
    Connect-NutanixCluster -Password $NTNXPwdSec -Server $CVM -UserName "admin" -AcceptInvalidSSLCerts -ForcedConnection
    <#
    # Delete default container and storagepool
    $CNTRID=Get-NTNXContainer |select id
    Remove-NTNXContainer -Id $CNTRID

    # Delete default storagepool
    $StoragePool=Get-NTNXStoragepool|select id
    remove-ntnxstoragepool -id $StoragePool

    # Setting the parameters for the cluster correctly
    $ClusterID=Get-NTNXClusterInfo | select id
    $CEName="ce$CEid"
    write-host "CEname is"$CEName
    Set-NTNXCluster -Name $CEName -NameServers 8.8.8.8 -Id $ClusterID

    # Disconnect the session
    Disconnect-NTNXCluster * 
    $CEid ++
    write-host "counter is on"$CEid
    #>

    New-NTNXSnapshot -NutanixClusters 
    #Wiping the variabels for next run
    $StoragePool=$null
    $ClusterID=$Null
    $CNTRID=$null


}
