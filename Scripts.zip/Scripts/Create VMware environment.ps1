﻿# *********************************************************************************
# Script for adding ESXi servers to vCenter server
# Parameters for the scripts to run:
# VMWare PowerCLI 6.3
# ----------------------------------------------------------------------------------
# Versioning
# v0.1 - Willem Essenstam - 19-04-2016
# *********************************************************************************

#
# Load the VMware PowerCLI modules
Add-PSSnapin VMware.VimAutomation.Core

# Setting the parameters needed
$vCenter="192.168.3.10"
$ESXi1="192.168.3.30"
$ESXi2="192.168.3.31"
$ESXi3="192.168.3.32"
#$ESXi4="192.168.3.33"
$ESXIHosts=$ESXi1,$ESXi2,$ESXi3,$ESXi4
$ESXUser="root"
$ESXPassword="nutanix/4u"
$VCUser="administrator@vsphere.local"
$VCPassword="Nutanix/4u"

# Connecting to the vCenter server
connect-viserver -server $vCenter -User $VCUser -Password $VCPassword

# Create the datacenter
New-Datacenter -Location Datacenters -Name DEMO -Confirm:$false


# Create the Cluster
New-Cluster -Location Demo -Name NPP -HAEnabled -DrsEnabled -DrsAutomationLevel FullyAutomated

# Add the ESXi hosts to the cluster
foreach ($VMHost in $ESXIHosts){
    Add-VMHost -Name $VMHost -Location NPP -User $ESXUser -Password $ESXPassword -Force -RunAsync
    }
# Remove the ESXi hosts to the cluster
#foreach ($VMHost in $ESXIHosts){
#    Remove-VMHost $VMHost -Confirm:$false 
#    }


# Disconnecting the vCenter
Disconnect-viserver -server $vCenter -Force -Confirm:$false